const { z } = require("zod");

//login schema

const loginSchema = z.object({
    email: z
        .string({required_error : "Email is required" })
        .trim()
        .email({message:"Invalid email address"})
        .min(3, { message: "Email Must be at least 3 character." })
        .max(255, { name: "Email must not be more than 255 characters." }),
    password: z
        .string({ required_error: "Password is required" })
        .trim()
        .min(6, { message: "Password Must be at least 6 character." })
        .max(255, { name: "Password must not be more than 255 characters." }),
});

//create object schema
const signUpSchema = loginSchema.extend({
    username: z
        .string({ required_error: "Name is required" })
        .trim()
        .min(3, { message: "Name Must be at least 3 character." })
        .max(255, { name: "Name must not be more than 255 characters." }),
    // email: z
    //     .string({ required_error: "Email is required" })
    //     .trim()
    //     .email({message:"Invalid email address"})
    //     .min(3, { message: "Email Must be at least 3 character." })
    //     .max(255, { name: "Email must not be more than 255 characters." }),
    phone: z
        .string({ required_error: "Phone is required" })
        .trim()
        .min(10, { message: "Phone Must be at least 10 character." })
        .max(20, { name: "Phone must not be more than 20 characters." }),
    // password: z
    //     .string({ required_error: "Password is required" })
    //     .trim()
    //     .min(6, { message: "Password Must be at least 6 character." })
    //     .max(255, { name: "Password must not be more than 255 characters." }),
});


// //login schema

// const loginSchema = z.object({
//     email: z
//         .string({required_error : "Email is required" })
//         .trim()
//         .email({message:"Invalid email address"})
//         .min(3, { message: "Email Must be at least 3 character." })
//         .max(255, { name: "Email must not be more than 255 characters." }),
//     password: z
//         .string({ required_error: "Password is required" })
//         .trim()
//         .min(6, { message: "Password Must be at least 6 character." })
//         .max(255, { name: "Password must not be more than 255 characters." }),
// });


module.exports = {signUpSchema,loginSchema};








