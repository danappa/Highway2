
const express = require("express");
const router = express.Router();
const citiesController = require("../controllers/cities-cotroller");


router.route("/cities").get(citiesController.cities);
router.route("/citiesSuggestion").get(citiesController.citiesSuggestion);


module.exports = router;










