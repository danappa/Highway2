
const jwt = require("jsonwebtoken");
const user = require("../models/user-model")

const authMiddleware = async (req, res, next) => {
    const token = req.header("Authorization");
    if (!token) {
        return res.status(401).json({ message: "Unauthorized HTTP, Token is not provided" })
    }
    console.log("token from auth middleware! ", token);

    //Assuming token is in format "Bearer <jwt token>" , Removing "Bearer " Prefix
    const jwtToken = token.replace("Bearer", "").trim();
    console.log("jwtToken from auth middleware! ", jwtToken);

    try {
        const isVerified = jwt.verify(jwtToken, process.env.JWT_SECRET_KEY);
        console.log("isVerified : ", isVerified);

        const userData = await user.findOne({ email: isVerified.email }).select({
            password: 0,
        });
        console.log(" userData : ", userData);
        req.user = userData;
        req.token = token;
        req.userID = userData._id;
        next();
    } catch (error) {

    }
}


module.exports = authMiddleware;












