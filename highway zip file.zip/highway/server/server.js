require("dotenv").config();
const express = require("express");
const cors=require('cors')
const app = express();
const authRouter = require("./router/auth-router");
const contactRoute= require("./router/contact-router")
const serviceRoute= require("./router/service-router")
const citiesRoute= require("./router/cities-router")
const connectDb=require("./utils/db");
const errorMiddleware= require("./middleware/error-middleware")

var corsOptions = {
    origin: 'http://localhost:5173',
    methods:"GET,POST,PUT,DELETE,PATCH",
    Credential:true,
    // optionsSuccessStatus: 200 
  }
// to handle CORS error
app.use(cors(corsOptions));

app.use(express.json())

app.use("/api/auth/", authRouter);
app.use("/api/form/", contactRoute);
app.use("/api/data/", serviceRoute);
app.use("/api/details/", citiesRoute);

app.use(errorMiddleware);

const PORT = 5000;

connectDb().then(()=>{
app.listen(PORT, () => {
    console.log(`server is running at port ${PORT}`)
})
});




