
const mongoose = require("mongoose"); 
const { Schema, model } = mongoose; 

const citiesSchema = new Schema({
    id: { type: String, required: true },
    cityName: { type: String, required: true },
    pincode: { type: String, required: true },
    country: { type: String, required: true },
    population: { type: String, required: true },
    area: { type: String, required: true },
    timezone: { type: String, required: true },
});


const Cities = model("Cities", citiesSchema);

module.exports = Cities;














