
const Cities = require("../models/cities-model");

const citiesSuggestion = async (req, res) => {
    try {
        const { cityName } = req.query;
        if (!cityName) {
            return res.status(400).json({ msg: "City name is required." });
        }
        const response = await Cities.find({
            cityName: { $regex: cityName, $options: 'i' } 
        }).limit(5);
        if (response.length === 0) {
            return res.status(404).json({ msg: "No services found" });
        }
        return res.status(200).json(response);
    } catch (error) {
        console.error("Cities service error:", error);
        return res.status(500).json({ msg: "Internal server error." });
    }
}

const cities = async (req, res) => {
    try {
        const { cityName } = req.query;
        if (!cityName) {
            return res.status(400).json({ msg: "City name is required." });
        }
        const response = await Cities.findOne({ cityName: cityName });

        if (!response) {
            res.status(404).json({ msg: "No services found" });
            return;
        }
        return res.status(200).json(response);

    } catch (error) {
        console.error("Cities service error:", error);
        return res.status(500).json({ msg: "Internal server error." });
    }
}

module.exports = { citiesSuggestion, cities };




















