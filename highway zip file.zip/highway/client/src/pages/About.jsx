import { useAuth } from "../store/auth";
import { useState, useEffect } from "react";
import { toast } from "react-toastify";
import useDebounce from "../components/useDebounce";

export const About = () => {
  const { user } = useAuth();
  const [cityDetails, setCityDetails] = useState("");
  const [cityResponse, setCityResponse] = useState(null);
  const [suggestions, setSuggestions] = useState([]);

  const debouncedCityDetails = useDebounce(cityDetails, 500);

  const HandleInput = (e) => {
    setCityDetails(e.target.value);
  };

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (debouncedCityDetails) {
        try {
          const response = await fetch(
            `http://localhost:5000/api/details/citiesSuggestion?cityName=${debouncedCityDetails}`,
            {
              method: "GET",
            }
          );
          if (response.ok) {
            const data = await response.json();
            setSuggestions(data.map((city) => city.cityName));
          } else {
            console.error("Failed to fetch city suggestions");
            setSuggestions([]);
          }
        } catch (error) {
          console.error("Error fetching suggestions", error);
        }
      } else {
        setSuggestions([]);
      }
    };

    fetchSuggestions();
  }, [debouncedCityDetails]);

  const CityName = async () => {
    setCityResponse("");
    try {
      const response = await fetch(
        `http://localhost:5000/api/details/cities?cityName=${cityDetails}`,
        {
          method: "GET",
        }
      );
      if (response.ok) {
        const data = await response.json();
        toast.success("City details found successfully.");
        setCityResponse(data);
        console.log("setCityResponse :", data);
      } else {
        toast.error("City not found, please enter valid city name!");
        console.error("Failed to fetch city details");
      }
    } catch (error) {
      console.log(" post city server error!", error);
    }
    setSuggestions([]);
  };
  const handleSuggestionClick = (suggestion) => {
    setCityDetails(suggestion);
    setSuggestions([]); // Clear suggestions after selection
    console.log("city response suggestion : ", suggestion);
  };
  console.log("city response: ", cityResponse);
  return (
    <>
      <p>{user ? `Hello ${user.username}` : ""}</p>
      <h1>welcome to About page</h1>
      <br />
      <br />
      <input
        type="text"
        name="cityName"
        placeholder="Exter your city. Ex:City-1"
        onChange={HandleInput}
        value={cityDetails}
      ></input>
      <button onClick={CityName}>Search</button>
      <br />
      <br />
      {suggestions.length > 0 && (
        <ul>
          {suggestions.map((suggestion, index) => (
            <li
              key={index}
              onClick={() => handleSuggestionClick(suggestion)}
              style={{ backgroundColor: "#cce6ff", cursor: "pointer" }}
            >
              {suggestion}
            </li>
          ))}
        </ul>
      )}
      <br />
      <br />
      <li>
        {cityResponse
          ? `City Name: ${cityResponse.cityName}`
          : cityDetails.cityName}
      </li>
      <li>
        {cityResponse
          ? `Country: ${cityResponse.country}`
          : cityDetails.country}
      </li>
      <li>
        {cityResponse
          ? `City population : ${cityResponse.population}`
          : cityDetails.population}
      </li>
      <li>
        {cityResponse ? `City area: ${cityResponse.area}` : cityDetails.area}
      </li>
      <li>
        {cityResponse
          ? `City timezone: ${cityResponse.timezone}`
          : cityDetails.timezone}
      </li>
    </>
  );
};
