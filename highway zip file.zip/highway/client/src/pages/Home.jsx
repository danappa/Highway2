export const Home=()=>{
    return <>
    <main>
        <section className="class-hero">
            <div className="container grid grid-two-cols">
                <div className="hero-content">
                    <p> i am developer </p>
                    <h1>Welcome to development</h1>
                    <p>
                        some description loading....
                    </p>
                    <div className="btn btn-group">
                        <a href="/contact"><button className="btn">connect now</button></a>
                    </div>
                    <div className="btn btn-group">
                        <a href="/services"><button className="btn secondary-btn">learn more</button></a>
                    </div>
                </div>
                <div className="her0-image">
                    <img src="/images/resister.png"
                    height="500px"
                    width="500px"
                    alt="lets coading together"
                    ></img>
                </div>
            </div>
        </section>
    </main>
    </>
}













