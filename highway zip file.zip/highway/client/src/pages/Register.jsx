import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../store/auth";
import "./Resister.css";

export const Register = () => {
    const [showError, setShowError] = useState("");
    const navigate = useNavigate();
    const { storeTokenInLS } = useAuth();
    const [user, setUser] = useState({
        username: "",
        email: "",
        phone: "",
        password: ""
    });

    // const dbounce = (func, delay) => {
    //     let timeout;
    //     return function (...args) {
    //         const context = this;
    //         if (timeout) {
    //             clearTimeout(timeout);
    //         }
    //         timeout = setTimeout(() => {
    //             func.apply(context, args);
    //         }, delay);
    //     };
    // };
    const HandleInput = (e) => {
        const { name, value } = e.target;
        setUser(prevUser => ({
            ...prevUser,
            [name]: value
        }));
    };
    // const debouncedHandleInput = dbounce(HandleInput, 300);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setShowError(""); // Clear previous errors
        try {
            const response = await fetch(`http://localhost:5000/api/auth/register`, {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(user),
            });

            const res_data = await response.json();
            console.log("response data : " + res_data.extraDetails);

            if (response.ok) {
                storeTokenInLS(res_data.token);
                setUser({ username: "", email: "", phone: "", password: "" });
                navigate("/");
            } else {
                alert(res_data.extraDetails?res_data.extraDetails:res_data.message)
                storeTokenInLS(res_data.token);
            }



            // if (!response.ok) {
            //     const res_data = await response.json();
            //     storeTokenInLS(res_data.token);
            //     const errorData = await response.json();
            //     setShowError(errorData.extraDetails || 'An error occurred');
            //     throw new Error(errorData.extraDetails || 'An error occurred');
            // }

            // const resData = await response.json();
            // storeTokenInLS(resData.token);
            // setUser({ username: "", email: "", phone: "", password: "" });
            // navigate("/login");
        } catch (error) {
            console.error("Registration response error:", error);
        }
    };

    return (
        <section>
            <main>
                <div className="section-registration" style={{ display: 'flex' }}>
                    <div className="container grid grid-two-cols">
                        <div className="registration-image">
                            <img
                                src="/images/resister.png"
                                alt="A girl is trying to register!"
                                width={500}
                                height={500}
                            />
                        </div>
                        <div className="registration-form">
                            <h1 className="main-heading mb-3">Registration</h1>
                            <form onSubmit={handleSubmit}>
                                <div>
                                    <label htmlFor="username">Username</label>
                                    <input
                                        type="text"
                                        name="username"
                                        value={user.username}
                                        onChange={HandleInput}
                                        placeholder="Username"
                                        id="username"
                                        required
                                        autoComplete="off"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="email">Email</label>
                                    <input
                                        type="email"
                                        name="email"
                                        value={user.email}
                                        onChange={HandleInput}
                                        placeholder="Email"
                                        id="email"
                                        required
                                        autoComplete="off"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="phone">Phone</label>
                                    <input
                                        type="tel"
                                        name="phone"
                                        value={user.phone}
                                        onChange={HandleInput}
                                        placeholder="Phone"
                                        id="phone"
                                        required
                                        autoComplete="off"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="password">Password</label>
                                    <input
                                        type="password"
                                        name="password"
                                        value={user.password}
                                        onChange={HandleInput}
                                        placeholder="Password"
                                        id="password"
                                        required
                                        autoComplete="off"
                                    />
                                </div>
                                {showError && <p style={{ color: 'red' }}>{showError}</p>}
                                <button type="submit" className="btn-btn-submit">Register Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </section>
    );
};
