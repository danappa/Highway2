const fs = require('fs');

function generateCities(num) {
    const cities = [];
    const countries = ["USA", "Japan", "UK", "France", "Australia", "India", "Germany", "Egypt", "Brazil", "Russia"];
    const timezones = ["UTC-5", "UTC+9", "UTC+0", "UTC+1", "UTC+10", "UTC+5:30", "UTC+1", "UTC+2", "UTC-3", "UTC+3"];

    for (let i = 1; i <= num; i++) {
        const city = {
            id: i,
            cityName: `City-${i}`,
            pincode: `${Math.floor(10000 + Math.random() * 90000)}`, // Random pincode
            country: countries[Math.floor(Math.random() * countries.length)],
            population: Math.floor(Math.random() * (20000000 - 100000 + 1)) + 100000, // Random population
            area: (Math.random() * (20000 - 50) + 50).toFixed(2), // Random area
            timezone: timezones[Math.floor(Math.random() * timezones.length)]
        };
        cities.push(city);
    }

    return cities;
}

// Generate 1000 city entries
const cityData = generateCities(10000);

// Write to a JSON file
fs.writeFile('cities.json', JSON.stringify(cityData, null, 4), (err) => {
    if (err) {
        console.error('Error writing file:', err);
    } else {
        console.log('Generated cities.json with 1000 entries.');
    }
});
