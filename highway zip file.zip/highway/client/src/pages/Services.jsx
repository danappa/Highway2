import { useEffect, useState } from "react"
import { useAuth } from "../store/auth"

export const Services = () => {
    // const [data, setData] = useState(null);
    const { services } = useAuth();
    // useEffect(() => {
    // const fetchData = async () => {
    //     try {
    //         const response = await fetch(`http://localhost:5000/api/data/service`, {
    //             method: 'GET',
    //         });
    //         if (response.ok) {
    //             const jsonData = await response.json()
    //             console.log("services card response ==>>", jsonData)
    //             setData(jsonData.msg)
    //         } else {
    //             console.log("error in services response  ")
    //         }
    //     } catch (error) {
    //         console.log(error)
    //     }
    // }
    //     fetchData();
    // }, [])




    return (
        <section className="section-services">
            <div className="container">
                <h1>Services</h1>
            </div>
            <div className="container grid grid-three-cols" style={{display:"flex" , flexWrap: "wrap"}}>
                {
                    services? (services.map((curEle, index) => {
                        const { price, provider, description, service } = curEle;
                        return (
                            <div className="card" key={index} >
                                <div className="card-img">
                                    <img src="/images/card.png" alt="our services info..." width="200"></img>
                                </div>
                                <div className="card-deatils">
                                    <div className="grid grid-two-cols">
                                        <p>provider: {provider}</p>
                                        <p>Price: {price}</p>
                                    </div>
                                    <h2>service: {service}</h2>
                                    <p>description : {description}</p>
                                </div>
                            </div>
                        )
                    }
                    )) :
                        (<p>loading...</p>)
                }
            </div>
        </section>
    )
}











