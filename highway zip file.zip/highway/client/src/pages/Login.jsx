import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../store/auth";
import { toast } from "react-toastify";
import useDebounce from "../components/useDebounce";

export const Login = () => {
    const navigate = useNavigate();
    const {storeTokenInLS} = useAuth();
    const [user, setUser] = useState({
        email: "",
        password: "",
    });

    const debouncedEmail = useDebounce(user.email, 300);
    const debouncedPassword = useDebounce(user.password, 300);

    const HandleInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        setUser((prevUser) => ({
            ...prevUser,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log("Submitting user data: ", { email: debouncedEmail, password: debouncedPassword });

        // Ensure we only submit the debounced values
        try {
            const response = await fetch(`http://localhost:5000/api/auth/login`, {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email: debouncedEmail, password: debouncedPassword }),
            });

            const res_data = await response.json();

            if (response.ok) {
                storeTokenInLS(res_data.token);
                console.log('storeTokenInLS : ',res_data.token)
                setUser({
                    email: "",
                    password: "",
                });
                toast.success("Login successful! ")
                navigate("/");
            } else {
                toast.error(res_data.extraDetails?res_data.extraDetails:res_data.message)
                console.error("Login failed:", res_data.message);
            }
        } catch (error) {
            console.error("Login request error:", error);
        }
    };

    return (
        <>
            <section>
                <main>
                    <div className="section-resistration" style={{ display: 'flex' }}>
                        <div className="container grid grid-two-cols"></div>
                        <div className="restraion-iimage">
                            <img
                                src="/images/resister.png"
                                alt="user login to application !"
                                width={500}
                                height={500}
                            />
                        </div>
                        <div className="resistration-form" style={{ width: '500px' }}>
                            <h1 className="main-heading mb-3">Login user</h1>
                            <br />
                            <form onSubmit={handleSubmit}>
                                <div>
                                    <label htmlFor="email">Email</label>
                                    <input
                                        type="email"
                                        name="email"
                                        value={user.email} // Use immediate state value
                                        onChange={HandleInput}
                                        placeholder="Email"
                                        id="email"
                                        required
                                        autoComplete="off"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="password">Password</label>
                                    <input
                                        type="password"
                                        name="password"
                                        value={user.password} // Use immediate state value
                                        onChange={HandleInput}
                                        placeholder="Password"
                                        id="password"
                                        required
                                        autoComplete="off"
                                    />
                                </div>
                                <br />
                                <button type="submit" className="btn-btn-submit">Login</button>
                            </form>
                        </div>
                    </div>
                </main>
            </section>
        </>
    );
};
