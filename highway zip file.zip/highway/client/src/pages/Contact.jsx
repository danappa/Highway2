import { useState } from "react"
import { useAuth } from "../store/auth";


const defaultContactForm = {
    username: "",
    email: "",
    message: "",
}

export const Contact = () => {
    const [contact, setContact] = useState(defaultContactForm);
    const [userData, setUserData] = useState({});

    const { user ,isLoggedIn} = useAuth();

    if (userData && user) {
        console.log(user)
        setContact({
            username: isLoggedIn?user.username:"",
            email: isLoggedIn?user.email:"",
            message: "",
        });
        setUserData(false);
    }

    const HandleInput = (e) => {
        let name = e.target.name;
        let value = e.target.value;
        setContact((prev) => ({
            ...prev,
            [name]: value,
        }))
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log('contact_comment : ', user)
        console.log('contact_comment_contact : ', contact)

        try {
            const response = await fetch('http://localhost:5000/api/form/contact', {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(contact)
            }
            )
            if (response.ok) {
                console.log("contact : ",contact);
                setContact(contact.message="")
            }
        } catch (error) {
            console.log(" post comment error!")
        }
        // alert(contact.email);
        console.log('contact ::',contact.message)
    }

    return <>
        <section>
            <main>
                <div className="section-resistration" style={{ display: 'flex' }}>
                    <div className="container grid grid-two-cols" ></div>
                    <div className="restraion-iimage">
                        <img
                            src="/images/resister.png"
                            alt="user login to application !"
                            width={500}
                            height={500}
                        ></img>
                    </div>
                    {/* //contact form */}
                    <div className="resistration-form">
                        <h1 className="main-heading mb-3"> Contact user </h1>
                        <br />
                        <form onSubmit={handleSubmit}>
                            <div>
                                <label htmlFor="username">username</label>
                                <input
                                    type="text"
                                    name="username"
                                    value={contact.username}
                                    onChange={HandleInput}
                                    placeholder="username"
                                    id="username"
                                    required
                                    autoComplete="off"
                                />
                            </div>
                            <div>
                                <label htmlFor="email">Email</label>
                                <input
                                    type="email"
                                    name="email"
                                    value={contact.email}
                                    onChange={HandleInput}
                                    placeholder="email"
                                    id="email"
                                    required
                                    autoComplete="off"
                                />
                            </div>

                            <div>
                                <label htmlFor="message">Message</label>
                                <textarea
                                    type="text"
                                    name="message"
                                    value={contact.message}
                                    onChange={HandleInput}
                                    placeholder="post your message here"
                                    id="message"
                                    required
                                    autoComplete="off"
                                    cols={30}
                                    rows={6}
                                />
                            </div>
                            <br />
                            <button type="submit" className="btn-btn-submit"> Login </button>
                        </form>
                    </div>
                </div>
            </main>
            <section >
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31105.71615141157!2d77.67192122027427!3d12.958120642024305!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1232926e3e27%3A0x209977809b7a70e!2sKalamandir!5e0!3m2!1sen!2sin!4v1728198727783!5m2!1sen!2sin"
                    width="600"
                    height="450"
                    // style="border:0"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </section>
        </section>

    </>
}













