import { Navigate } from "react-router-dom";
import { useAuth } from "../store/auth";

const ProtectedRoute = ({ children }) => {
    const { isLoggedIn } = useAuth();
    return isLoggedIn ? <Navigate to="/" /> : children; 
};

export default ProtectedRoute;
