import { createContext, useContext, useEffect, useState } from "react";

export const Authcontext = createContext();

export const Authprovider = ({ children }) => {
    const [token, setToken] = useState(localStorage.getItem("token"));
    const [user, setUser] = useState()
    const [services, setServices] = useState(null);


    const storeTokenInLS = (serverToken) => {
        setToken(serverToken);
        return localStorage.setItem('token', serverToken)
    }

    let isLoggedIn = !!token;

    //tackling the logout functionality
    const LogoutUser = () => {
        setToken("");
        return localStorage.removeItem("token");
    }

    //jwt authentication- to get the current logged in user creds
    const userAuthentication = async () => {
        console.log("userAuthentication : " + token)
        try {
            const response = await fetch("http://localhost:5000/api/auth/user",
                {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`,
                    }
                }
            )
            console.log(`Bearer ${token}`)
            console.log(`response.ok ${response.ok}`)
            if (response.ok) {
                const data = await response.json();
                setUser(data.userData)
                console.log("user date : " + data.userData.username)
            }
        } catch (error) {
            console.log(error)
        }
    }


    const getServices = async () => {
        try {

            const response = await fetch(`http://localhost:5000/api/data/service`, {
                method: 'GET',
            });
            if (response.ok) {
                const jsonData = await response.json()
                console.log("services card response : ", jsonData)
                setServices(jsonData.msg)
            } else {
                console.log("error in services response  ")
            }
        } catch (error) {
            console.log(error)
        }
    }


    useEffect(() => {
        getServices();
        userAuthentication();
    }, []);

    return <Authcontext.Provider value={{ isLoggedIn, storeTokenInLS, LogoutUser, user,services }}>
        {children}
    </Authcontext.Provider>
}



export const useAuth = () => {
    const authContextValue = useContext(Authcontext)
    if (!authContextValue) {
        throw new Error("useAuth is used outside of the provider");
    }
    return authContextValue;
}







